require('dotenv').config();
const express = require('express');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');
const CATALOG = require('./public/catalog.js');

const { DB_HOST = 'localhost', DB_PORT = 3306, DB_USER, DB_PASSWORD, DB_NAME = 'spicezy', JWT_SECRET, PORT = 3000, NODE_ENV } = process.env;
if (!JWT_SECRET || JWT_SECRET.length < 32) { console.error('Set JWT_SECRET (32+ characters) in your .env file.'); process.exit(1); }
const pool = mysql.createPool({ host: DB_HOST, port: DB_PORT, user: DB_USER, password: DB_PASSWORD, database: DB_NAME, connectionLimit: 10 });

class Err extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const bad = m => { throw new Err(400, m); };
const wrap = fn => (req, res, next) => fn(req, res, next).catch(next);
const str = (v, n) => String(v ?? '').trim().slice(0, n);
const int = (v, lo, hi, m) => { const n = Math.round(Number(v)); if (!Number.isFinite(n) || n < lo || n > hi) bad(m); return n; };
const CATS = ['Pure Powders', 'Whole Spices', 'Blended Masalas', 'Non-Veg Masalas', 'South Indian', 'Herbs & Botanicals', 'Combo Packs', 'Gift Packs'];
const STEPS = ['Order Placed', 'Packed', 'Shipped', 'Out for Delivery', 'Delivered', 'Cancelled'];
const ID_RE = /^[A-Za-z0-9_~.-]{1,100}$/;
const IMG_OK = /^(data:image\/(png|jpe?g|webp|gif);base64,|https?:\/\/|images\/)/i;
const likeEsc = s => s.replace(/[\\%_]/g, '\\$&');

/* ---------- document helpers ---------- */
const getDoc = async (c, id, q = pool, lock = false) => { const [[r]] = await q.query('SELECT data FROM docs WHERE coll = ? AND id = ?' + (lock ? ' FOR UPDATE' : ''), [c, id]); return r ? JSON.parse(r.data) : null; };
const putDoc = (c, id, d, q = pool) => q.query('INSERT INTO docs (coll, id, uid, ts, data) VALUES (?,?,?,?,?) ON DUPLICATE KEY UPDATE uid = VALUES(uid), ts = VALUES(ts), data = VALUES(data)', [c, id, d.uid ? String(d.uid) : null, Number(d.ts) || 0, JSON.stringify(d)]);
const delDoc = (c, id, q = pool) => q.query('DELETE FROM docs WHERE coll = ? AND id = ?', [c, id]);
const rowsOf = async (c, where = '', params = []) => { const [r] = await pool.query('SELECT id, data FROM docs WHERE coll = ? ' + where + ' ORDER BY ts DESC LIMIT 5000', [c, ...params]); return r.map(x => ({ id: x.id, data: JSON.parse(x.data) })); };
const skuOf = (pid, vid) => (vid && vid !== 'std' ? pid + '~' + vid : pid);
const variantsOf = p => (p.variants && p.variants.length ? p.variants : [{ id: 'std', w: '', price: p.price }]);

/* ---------- validators (whitelist every field) ---------- */
function vProduct(d) {
  const name = str(d.name, 150); if (!name) bad('Product name is required');
  if (!CATS.includes(d.cat)) bad('Choose a valid category');
  let variants = null;
  if (Array.isArray(d.variants) && d.variants.length) {
    variants = d.variants.slice(0, 8).map(v => ({ id: str(v.id, 12), w: str(v.w, 20), price: int(v.price, 1, 1e6, 'Invalid price') }));
    if (variants.some(v => !/^[a-z0-9]{1,12}$/.test(v.id)) || new Set(variants.map(v => v.id)).size !== variants.length) bad('Invalid weight options');
  }
  const price = variants ? variants[0].price : int(d.price, 1, 1e6, 'Invalid price');
  const img = str(d.img, 1e6), gallery = (Array.isArray(d.gallery) ? d.gallery : []).slice(0, 2).map(g => str(g, 1e6)).filter(Boolean);
  for (const u of [img, ...gallery]) if (u && (u.length > 900000 || !IMG_OK.test(u))) bad('Invalid or too large image');
  const out = { name, cat: d.cat, price, emoji: str(d.emoji, 8), desc: str(d.desc, 500), ing: str(d.ing, 1000),
    tags: (Array.isArray(d.tags) ? d.tags : []).slice(0, 10).map(t => str(t, 30)).filter(Boolean), img, gallery, ts: Number(d.ts) || Date.now() };
  if (variants) out.variants = variants;
  if (d.rating != null && d.rating !== '') { const r = Number(d.rating); if (r >= 0 && r <= 5) out.rating = Math.round(r * 10) / 10; }
  return out;
}
const vStock = d => ({ n: int(d.n, 0, 1e6, 'Stock must be a whole number') });
function vSettings(d) {
  return { fee: int(d.fee ?? 30, 0, 1e4, 'Invalid delivery fee'), free: int(d.free ?? 499, 0, 1e6, 'Invalid free-delivery amount'), days: int(d.days ?? 3, 0, 60, 'Invalid delivery days'),
    low: int(d.low ?? 10, 0, 1e5, 'Invalid low-stock level'), store: str(d.store, 80), addr: str(d.addr, 300), phone: str(d.phone, 20), gstin: str(d.gstin, 20),
    areas: (Array.isArray(d.areas) ? d.areas : []).slice(0, 300).map(a => ({ p: str(a.p, 6), d: int(a.d, 0, 60, 'Invalid delivery days') })).filter(a => /^\d{1,6}$/.test(a.p)) };
}
function vCoupon(d, id) {
  const code = str(d.code, 20).toUpperCase(); if (!/^[A-Z0-9]{3,20}$/.test(code) || code !== id) bad('Invalid coupon code');
  const type = d.type === 'flat' ? 'flat' : 'percent', value = int(d.value, 1, 1e6, 'Invalid discount');
  if (type === 'percent' && value > 100) bad('Percent must be 1-100');
  return { code, type, value, min: int(d.min || 0, 0, 1e6, 'Invalid minimum'), start: Number(d.start) || 0, exp: Number(d.exp) || 0, limit: int(d.limit || 0, 0, 1e6, 'Invalid limit'), active: d.active !== false, show: d.show === true };
}

/* ---------- sessions ---------- */
const COOKIE = 'sz_sess';
const sessFrom = req => { try { return jwt.verify(req.cookies[COOKIE], JWT_SECRET); } catch { return null; } };
const need = req => { if (!req.sess) throw new Err(401, 'Please log in'); return req.sess; };
const needAdmin = req => { if (!need(req).admin) throw new Err(403, 'Admin only'); return req.sess; };
const setSess = (res, u) => res.cookie(COOKIE, jwt.sign({ id: String(u.id), name: u.name, email: u.email, admin: !!u.is_admin }, JWT_SECRET, { expiresIn: '8h' }),
  { httpOnly: true, sameSite: 'strict', secure: NODE_ENV === 'production', maxAge: 8 * 3600 * 1000 });
const pub = u => ({ id: String(u.id), name: u.name, email: u.email, admin: !!u.is_admin });
const DUMMY = bcrypt.hashSync('not-a-real-password', 12);

const app = express();
app.disable('x-powered-by');
app.use(helmet({ hsts: false, contentSecurityPolicy: { useDefaults: false, directives: {
  defaultSrc: ["'self'"], scriptSrc: ["'self'", "'unsafe-inline'"], scriptSrcAttr: ["'unsafe-inline'"], styleSrc: ["'self'", "'unsafe-inline'"],
  imgSrc: ["'self'", 'data:', 'https:'], connectSrc: ["'self'"], objectSrc: ["'none'"], baseUri: ["'self'"], formAction: ["'self'"], frameAncestors: ["'self'"] } } }));
app.use(cookieParser());
app.use((req, res, next) => { req.sess = sessFrom(req); next(); });
const big = express.json({ limit: '4mb' }), small = express.json({ limit: '100kb' });
app.use((req, res, next) => (req.sess && req.sess.admin ? big : small)(req, res, next));
app.use('/api', (req, res, next) => {
  res.set('Cache-Control', 'no-store');
  if (!['GET', 'HEAD'].includes(req.method) && req.get('x-requested-with') !== 'spicezy') return res.status(403).json({ error: 'Blocked request' });
  next();
});

/* ---------- accounts ---------- */
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 40, message: { error: 'Too many attempts. Try again in 15 minutes.' } });
app.get('/api/ping', (req, res) => res.json({ app: 'spicezy' }));
app.get('/api/me', (req, res) => { const s = need(req); res.json({ id: s.id, name: s.name, email: s.email, admin: !!s.admin }); });
app.post('/api/register', authLimiter, wrap(async (req, res) => {
  const name = str(req.body?.name, 100), email = str(req.body?.email, 255).toLowerCase(), pw = String(req.body?.password || '');
  if (!name) bad('Enter your name.');
  if (!/^[^\s@]{1,64}@[^\s@]{1,190}\.[^\s@]{2,}$/.test(email)) bad('Enter a valid email address.');
  if (pw.length < 8 || pw.length > 72) bad('Password must be 8 to 72 characters.');
  try {
    const [r] = await pool.query('INSERT INTO users (name, email, password_hash) VALUES (?,?,?)', [name, email, await bcrypt.hash(pw, 12)]);
    const u = { id: r.insertId, name, email, is_admin: 0 }; setSess(res, u); res.status(201).json(pub(u));
  } catch (e) { if (e.code === 'ER_DUP_ENTRY') throw new Err(409, 'An account with this email already exists.'); throw e; }
}));
app.post('/api/login', authLimiter, wrap(async (req, res) => {
  const [[u]] = await pool.query('SELECT * FROM users WHERE email = ?', [str(req.body?.email, 255).toLowerCase()]);
  const ok = await bcrypt.compare(String(req.body?.password || ''), u ? u.password_hash : DUMMY);
  if (!u || !ok) throw new Err(401, 'Incorrect email or password.');
  setSess(res, u); res.json(pub(u));
}));
app.post('/api/logout', (req, res) => { res.clearCookie(COOKIE); res.json({ ok: true }); });

/* ---------- shared business rules ---------- */
const cfgOf = async q => ({ fee: 30, free: 499, days: 3, low: 10, areas: [], ...(await getDoc('settings', 'main', q) || {}) });
function dlvOf(pin, cfg) {
  if (!/^[1-9]\d{5}$/.test(pin)) return { ok: false, msg: 'Enter a valid 6-digit PIN code.' };
  const areas = cfg.areas || [], a = areas.slice().sort((x, y) => y.p.length - x.p.length).find(x => pin.startsWith(x.p));
  if (areas.length && !a) return { ok: false, msg: 'Sorry, we do not deliver to ' + pin + ' yet.' };
  return { ok: true, days: a ? a.d : cfg.days };
}
async function couponCheck(q, code, sub, lock) {
  code = str(code, 20).toUpperCase(); if (!code) throw new Err(400, 'Enter a coupon code.');
  const c = await getDoc('coupons', code, q); if (!c) throw new Err(400, 'Invalid coupon code.');
  if (!c.active) throw new Err(400, 'This coupon is not active.');
  if (c.start && Date.now() < c.start) throw new Err(400, 'This coupon is not valid yet.');
  if (c.exp && Date.now() > c.exp) throw new Err(400, 'This coupon has expired.');
  if (sub < (c.min || 0)) throw new Err(400, 'Add items worth ₹' + c.min + ' or more to use this coupon.');
  const u = await getDoc('couponUse', code, q, lock); if (c.limit && u && u.n >= c.limit) throw new Err(400, 'This coupon has reached its usage limit.');
  return { c, u };
}
const discOf = (sub, c) => (!c ? 0 : Math.min(sub, c.type === 'percent' ? Math.floor(sub * c.value / 100) : c.value));
const bump = async (q, coll, id, by) => { const d = await getDoc(coll, id, q, true) || { n: 0 }; await putDoc(coll, id, { n: Math.max(0, (d.n || 0) + by) }, q); };
async function tx(fn) { const q = await pool.getConnection(); try { await q.beginTransaction(); const r = await fn(q); await q.commit(); return r; } catch (e) { await q.rollback(); throw e; } finally { q.release(); } }

app.post('/api/coupon', wrap(async (req, res) => { need(req); res.json((await couponCheck(pool, req.body?.code, Number(req.body?.sub) || 0, false)).c); }));

const orderLimiter = rateLimit({ windowMs: 60 * 1000, max: 12, message: { error: 'Too many orders. Please wait a minute.' } });
app.post('/api/checkout', orderLimiter, wrap(async (req, res) => {
  const s = need(req), b = req.body || {};
  const name = str(b.name, 100), phone = str(b.phone, 15), addr = str(b.addr, 600), pin = str(b.pin, 6);
  if (!name) bad('Enter your name.');
  if (!/^\d{10}$/.test(phone)) bad('Enter a valid 10-digit phone number.');
  if (addr.length < 5) bad('Enter the delivery address.');
  if (!Array.isArray(b.items) || !b.items.length || b.items.length > 50) bad('Your cart is empty.');
  const merged = {};
  for (const i of b.items) {
    const id = str(i.id, 100), vid = str(i.vid || 'std', 12), q = int(i.q, 1, 100, 'Invalid quantity');
    if (!ID_RE.test(id)) bad('Invalid cart item');
    const k = id + '|' + vid; merged[k] = { id, vid, q: (merged[k]?.q || 0) + q };
  }
  const items = Object.values(merged).sort((a, c) => skuOf(a.id, a.vid).localeCompare(skuOf(c.id, c.vid)));
  const out = await tx(async q => {
    const cfg = await cfgOf(q), dl = dlvOf(pin, cfg); if (!dl.ok) bad(dl.msg);
    const lines = []; let sub = 0; const perProduct = {};
    for (const it of items) {
      const p = await getDoc('products', it.id, q); if (!p) bad('A product in your cart is no longer available.');
      const v = variantsOf(p).find(x => x.id === it.vid); if (!v) bad(p.name + ' is no longer available in that size.');
      const sk = skuOf(it.id, it.vid), st = await getDoc('stock', sk, q, true), n = st ? st.n : 0;
      if (n < it.q) bad(n ? 'Only ' + n + ' left of ' + p.name + (v.w ? ' ' + v.w : '') : p.name + (v.w ? ' ' + v.w : '') + ' is out of stock.');
      await putDoc('stock', sk, { n: n - it.q }, q);                  // price ALWAYS comes from the database
      sub += v.price * it.q; perProduct[it.id] = (perProduct[it.id] || 0) + it.q;
      lines.push({ id: it.id, vid: it.vid, n: p.name, w: v.w, q: it.q, price: v.price });
    }
    let cp = null, disc = 0;
    if (str(b.coupon, 20)) { cp = (await couponCheck(q, b.coupon, sub, true)).c; disc = discOf(sub, cp); }
    const fee = sub && sub < cfg.free ? cfg.fee : 0, now = Date.now();
    let id = 'SZ' + String(now).slice(-7); if (await getDoc('orders', id, q)) id += Math.floor(Math.random() * 90 + 10);
    const o = { name, phone, addr, pin, email: s.email, items: lines, sub, fee, disc, coupon: cp ? cp.code : '', total: sub - disc + fee, status: 'Order Placed',
      uid: s.id, ts: now, eta: now + dl.days * 864e5, pay: 'COD', hist: [{ s: 'Order Placed', t: now }] };
    await putDoc('orders', id, o, q);
    if (cp) await bump(q, 'couponUse', cp.code, 1);
    for (const [pid, n] of Object.entries(perProduct)) await bump(q, 'sold', pid, n);
    return { id, total: o.total, eta: o.eta };
  });
  res.status(201).json(out);
}));

async function setStatus(q, o, id, status) {
  const items = o.items || [], was = o.status === 'Cancelled', now = status === 'Cancelled';
  if (was !== now) {
    const per = {};
    for (const i of items) {
      const sk = skuOf(i.id, i.vid), st = await getDoc('stock', sk, q, true);
      if (st) await putDoc('stock', sk, { n: Math.max(0, st.n + (now ? i.q : -i.q)) }, q);
      per[i.id] = (per[i.id] || 0) + i.q;
    }
    for (const [pid, n] of Object.entries(per)) await bump(q, 'sold', pid, now ? -n : n);
    if (o.coupon) await bump(q, 'couponUse', o.coupon, now ? -1 : 1);
  }
  const hist = (o.hist || [{ s: 'Order Placed', t: o.ts }]).concat({ s: status, t: Date.now() });
  await putDoc('orders', id, { ...o, status, hist }, q);
}
async function recompute(pid) {
  const [r] = await pool.query('SELECT data FROM docs WHERE coll = ? AND id LIKE ? ESCAPE ?', ['reviews', likeEsc(pid) + '\\_%', '\\']);
  const rs = r.map(x => JSON.parse(x.data)).filter(x => x.pid === pid);
  if (!rs.length) return delDoc('ratings', pid);
  await putDoc('ratings', pid, { avg: Math.round(rs.reduce((a, x) => a + x.rating, 0) / rs.length * 10) / 10, n: rs.length });
}

/* ---------- generic document API (the contract the front end expects) ---------- */
// r = who may read, w = how writes are handled
const COL = { products: { r: 'pub' }, stock: { r: 'pub' }, settings: { r: 'pub' }, sold: { r: 'pub' }, ratings: { r: 'pub' }, reviews: { r: 'pub' },
  coupons: { r: 'coupon' }, couponUse: { r: 'admin' }, orders: { r: 'owner' }, feedback: { r: 'owner' }, wish: { r: 'own' } };
const colOf = c => COL[c] || (() => { throw new Err(404, 'Not found'); })();
const canSee = (def, req, doc, id) => def.r === 'pub' || (req.sess && (req.sess.admin || (def.r === 'owner' && doc && String(doc.uid) === req.sess.id) || (def.r === 'own' && id === req.sess.id)));

app.get('/api/c/:coll', wrap(async (req, res) => {
  const def = colOf(req.params.coll), s = req.sess; let rows;
  if (def.r === 'pub') rows = await rowsOf(req.params.coll);
  else if (def.r === 'coupon') { rows = await rowsOf('coupons'); if (!s || !s.admin) rows = rows.filter(r => r.data.show === true); }
  else if (def.r === 'owner') rows = need(req) && s.admin ? await rowsOf(req.params.coll) : await rowsOf(req.params.coll, 'AND uid = ?', [s.id]);
  else { needAdmin(req); rows = await rowsOf(req.params.coll); }
  const { f, v, sort, dir } = req.query;
  if (f) rows = rows.filter(r => String(r.data[f]) === String(v));
  if (sort) rows.sort((a, b) => ((Number(b.data[sort]) || 0) - (Number(a.data[sort]) || 0)) * (dir === 'desc' ? 1 : -1));
  res.json(rows);
}));
app.get('/api/c/:coll/:id', wrap(async (req, res) => {
  const def = colOf(req.params.coll), { coll, id } = req.params;
  if (!ID_RE.test(id)) throw new Err(404, 'Not found');
  if (def.r === 'coupon' || def.r === 'admin') needAdmin(req);
  const d = await getDoc(coll, id); if (!d) throw new Err(404, 'Not found');
  if (!canSee(def, req, d, id)) throw new Err(req.sess ? 403 : 401, 'Not allowed');
  res.json(d);
}));

const write = op => wrap(async (req, res) => {
  const { coll, id } = req.params; colOf(coll);
  if (!ID_RE.test(id)) bad('Invalid id');
  const s = need(req), body = req.body || {};
  const old = await getDoc(coll, id);
  const merged = op === 'merge' ? { ...(old || {}), ...body } : body;
  if (coll === 'products') {
    needAdmin(req);
    if (op === 'del') {
      await delDoc('products', id); await delDoc('stock', id);
      await pool.query('DELETE FROM docs WHERE coll = ? AND id LIKE ? ESCAPE ?', ['stock', likeEsc(id) + '~%', '\\']);
    } else await putDoc('products', id, vProduct(merged));
  } else if (coll === 'stock') { needAdmin(req); op === 'del' ? await delDoc('stock', id) : await putDoc('stock', id, vStock(merged)); }
  else if (coll === 'settings') { needAdmin(req); if (id !== 'main') bad('Invalid id'); op === 'del' ? await delDoc('settings', id) : await putDoc('settings', id, vSettings(merged)); }
  else if (coll === 'coupons') { needAdmin(req); op === 'del' ? await delDoc('coupons', id) : await putDoc('coupons', id, vCoupon(merged, id)); }
  else if (coll === 'feedback') {
    if (op === 'del') { needAdmin(req); await delDoc('feedback', id); }
    else if (s.admin && old) { const st = str(body.status, 12); if (!['New', 'Reviewed', 'Resolved'].includes(st)) bad('Invalid status'); await putDoc('feedback', id, { ...old, status: st }); }
    else {
      if (old || !id.startsWith(s.id + '_')) throw new Err(403, 'Not allowed');
      const [[last]] = await pool.query("SELECT MAX(ts) AS t FROM docs WHERE coll = 'feedback' AND uid = ?", [s.id]);
      if (last.t && Date.now() - last.t < 10000) throw new Err(429, 'Please wait a few seconds before sending again.');
      const msg = str(body.msg, 1000); if (msg.length < 10) bad('Please write at least 10 characters.');
      const type = ['Review', 'Complaint', 'Suggestion'].includes(body.type) ? body.type : 'Review';
      await putDoc('feedback', id, { uid: s.id, name: s.name, type, rating: int(body.rating || 0, 0, 5, 'Invalid rating'), orderId: str(body.orderId, 20), msg, status: 'New', ts: Date.now() });
    }
  } else if (coll === 'reviews') {
    if (op === 'del') {
      if (!old) throw new Err(404, 'Not found'); if (!s.admin && old.uid !== s.id) throw new Err(403, 'Not allowed');
      await delDoc('reviews', id); await recompute(old.pid);
    } else {
      const pid = str(body.pid, 100); if (id !== pid + '_' + s.id) throw new Err(403, 'Not allowed');
      const [mine] = await pool.query('SELECT data FROM docs WHERE coll = ? AND uid = ?', ['orders', s.id]);
      if (!mine.some(r => { const o = JSON.parse(r.data); return o.status !== 'Cancelled' && (o.items || []).some(i => i.id === pid); })) throw new Err(403, 'Only customers who bought this product can review it.');
      const text = str(body.text, 1000); if (text.length < 5) bad('Please write at least 5 characters.');
      await putDoc('reviews', id, { pid, uid: s.id, name: s.name, rating: int(body.rating, 1, 5, 'Choose a rating from 1 to 5'), text, ts: Date.now() });
      await recompute(pid);
    }
  } else if (coll === 'wish') {
    if (id !== s.id) throw new Err(403, 'Not allowed');
    op === 'del' ? await delDoc('wish', id) : await putDoc('wish', id, { ids: (Array.isArray(merged.ids) ? merged.ids : []).slice(0, 300).map(x => str(x, 100)).filter(x => ID_RE.test(x)) });
  } else if (coll === 'orders') {
    if (op !== 'merge') throw new Err(403, 'Orders cannot be replaced or deleted');
    const status = str(body.status, 20); if (!STEPS.includes(status)) bad('Invalid status');
    await tx(async q => {
      const o = await getDoc('orders', id, q, true); if (!o) throw new Err(404, 'Order not found');
      if (!s.admin) { if (o.uid !== s.id) throw new Err(403, 'Not allowed'); if (status !== 'Cancelled' || o.status !== 'Order Placed') throw new Err(403, 'This order can no longer be cancelled.'); }
      if (o.status !== status) await setStatus(q, o, id, status);
    });
  } else throw new Err(403, 'Read-only');
  res.json({ ok: true });
});
app.put('/api/c/:coll/:id', write('set'));
app.patch('/api/c/:coll/:id', write('merge'));
app.delete('/api/c/:coll/:id', write('del'));

/* ---------- first-run data ---------- */
async function seed() {
  const [[c]] = await pool.query("SELECT COUNT(*) AS n FROM docs WHERE coll = 'products'");
  if (!c.n) {
    const base = Date.now() - 1e6;
    for (const p of CATALOG) {
      const d = { name: p.name, cat: p.cat, price: p.price, emoji: p.emoji, desc: p.desc, ing: p.ing || '', tags: p.tags || [], img: '', gallery: [], ts: base + p.ord };
      if (p.variants) d.variants = p.variants; if (p.rating) d.rating = p.rating;
      await putDoc('products', p.id, d);
      for (const [vid, n] of Object.entries(p.n)) await putDoc('stock', skuOf(p.id, vid), { n });
    }
    console.log('Added ' + CATALOG.length + ' starter products (placeholder prices and stock: review them in Admin).');
  }
  const [[k]] = await pool.query("SELECT COUNT(*) AS n FROM docs WHERE coll = 'coupons'");
  if (!k.n) {
    await putDoc('coupons', 'WELCOME10', { code: 'WELCOME10', type: 'percent', value: 10, min: 0, start: 0, exp: 0, limit: 0, active: true, show: true });
    await putDoc('coupons', 'FLAT50', { code: 'FLAT50', type: 'flat', value: 50, min: 299, start: 0, exp: 0, limit: 0, active: true, show: true });
  }
}

app.use(express.static(path.join(__dirname, 'public')));
app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));
app.use((err, req, res, next) => {
  if (err instanceof Err) return res.status(err.status).json({ error: err.message });
  if (err.type === 'entity.too.large') return res.status(413).json({ error: 'Upload too large. Use smaller photos.' });
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Bad request' });
  console.error(err); res.status(500).json({ error: 'Server error' });
});
app.listen(PORT, () => {
  console.log('Spicezy → http://localhost:' + PORT);
  seed().catch(e => console.error('\nDATABASE PROBLEM:', e.message, '\nCheck DB_USER / DB_PASSWORD in .env and that schema.sql was run.\n'));
});
