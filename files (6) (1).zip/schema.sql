-- Run once in MySQL Workbench. Your other databases are NOT touched.
CREATE DATABASE IF NOT EXISTS spicezy CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE spicezy;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(100) NOT NULL,
  is_admin TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- One document table matches the store's front end: products, stock, orders, coupons,
-- reviews, ratings, wishlists, feedback, settings, sold counters.
CREATE TABLE IF NOT EXISTS docs (
  coll VARCHAR(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  id   VARCHAR(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  uid  VARCHAR(20) NULL,
  ts   BIGINT NOT NULL DEFAULT 0,
  data LONGTEXT NOT NULL,
  PRIMARY KEY (coll, id),
  INDEX (coll, uid),
  INDEX (coll, ts)
);

-- App user (the app never uses root). CHANGE THE PASSWORD and use the same one in .env
CREATE USER IF NOT EXISTS 'spicezy_user'@'localhost' IDENTIFIED BY 'change-this-db-password';
GRANT SELECT, INSERT, UPDATE, DELETE ON spicezy.* TO 'spicezy_user'@'localhost';
FLUSH PRIVILEGES;
