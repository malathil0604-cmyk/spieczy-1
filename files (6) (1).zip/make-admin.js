// Usage: npm run make-admin -- someone@example.com
// First register that e-mail on the website, then run this once to give it admin access.
require('dotenv').config();
const mysql = require('mysql2/promise');
(async () => {
  const email = (process.argv[2] || '').trim().toLowerCase();
  if (!email) { console.log('Usage: npm run make-admin -- <email>'); process.exit(1); }
  const db = await mysql.createConnection({ host: process.env.DB_HOST || 'localhost', port: process.env.DB_PORT || 3306,
    user: process.env.DB_USER, password: process.env.DB_PASSWORD, database: process.env.DB_NAME || 'spicezy' });
  const [r] = await db.query('UPDATE users SET is_admin = 1 WHERE email = ?', [email]);
  console.log(r.affectedRows ? email + ' is now an admin. Log out and log in again.' : 'No account with that e-mail. Register it on the website first.');
  await db.end();
})().catch(e => { console.error(e.message); process.exit(1); });
